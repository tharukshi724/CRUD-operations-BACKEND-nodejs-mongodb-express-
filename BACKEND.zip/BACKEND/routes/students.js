const router=require("express").Router();
let Student = require("../module/student");

//add students
router.route("/add").post((req,res)=>{

    const name = req.body.name;
    const age = req.body.age;
    const gender = req.body.gender;

    const newStudent = new Student({

        name,
        age,
        gender
    })

    newStudent.save().then(() =>{

        res.json("Student Added");
    }).catch((err)=>{

        console.log(err);
    })

})

//display students
router.route("/").get((req,res)=>{
Student.find().then((students) =>{

         res.json(students);
}).catch((err) => {

    console.log(err);
})

})

//update student data
router.route("/update/:id").put(async(req,res)=>{
   let userId =req.params.id;  //fetch backend url id
    const {name,age,gender}  = req.body;   //destructure new feature of js
    
    const updateStudent ={
        name,
        age,
        gender
    }

    const update = await Student.findByIdAndUpdate(userId,updateStudent).then(()=>{
        res.status(200).send({status:"user updated"})
    }). catch((err) =>{
        console.log(err);//display error in console
        res.status(500).send({status:"error with updating data"});
    })

   
})

//delete user
router.route("/delete/:id").delete(async(req,res) => {
let userId = req.params.id;
await Student.findByIdAndDelete(userId).then(()=>{
    res.status(200).send({status:"user deleted"});
}).catch((err)=>{
   console.log(err);
   res.status(500).send({status:"error in deleting user"});
})
       
})

//fetch data of one student
router.route("/get/:id").get(async(req,res)=>{

      let userId = req.params.id;
      await Student.findById(userId).then(() =>{

        res.status(200).send({status:"display data"});

      }).catch((err) => {
          console.log(err);
          res.status(500).send({status:"error in displaying data"});
      })
})
module.exports = router;